#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include <stddef.h>

int
main(int argc, char *argv[])
{
  struct processinfo* p = NULL;

  get_process_info(p);

  exit(0);
}
