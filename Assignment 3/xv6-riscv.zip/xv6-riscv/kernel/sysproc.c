#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"
#include "kernel/processinfo.h"

uint64
sys_exit(void)
{
  int n;
  if(argint(0, &n) < 0)
    return -1;
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  if(argaddr(0, &p) < 0)
    return -1;
  return wait(p);
}

uint64
sys_sbrk(void)
{
  int addr;
  int n;
  /***********************/
  myproc()->traced = 0;
  /***********************/

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  /*
  if(growproc(n) < 0)
    return -1;
  */
  myproc()->sz += n;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  /**********************************/
  printf("sleeping for %d ticks\n", n);
  /**********************************/
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

/***************************************************/

uint64
sys_echo_simple(void)
{
  char str[MAXPATH];

  if(argstr(0,str,MAXPATH) < 0)
    return 1;
  else
    printf("%s\n",str);

  return 0;
}

uint64
sys_echo_kernel(void)
{
  char *argv[MAXARG];
  uint64 uargv, uarg;

  if(argaddr(1, &uargv) < 0){
    return -1;
  }

  memset(argv, 0, sizeof(argv));

  for(int i=0; i<NELEM(argv); i++){
    fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg);

    if(uarg == 0){
      argv[i] = 0;
      break;
    }

    argv[i] = kalloc();
    fetchstr(uarg, argv[i], PGSIZE);
  }

  for(int i = 1; i < NELEM(argv) && argv[i] != 0; i++){
    printf("%s ",argv[i]);
    kfree(argv[i]);
  }
  printf("\n");

  return 0;
}

uint64
sys_trace(void)
{
  int n;

  if(argint(0, &n) < 0)
    return -1;

  for (int i=0; i<32; i++){
    myproc()->mask[i] = n%2;
    n /= 2;
  }
  
  myproc()->traced = 1;

  return 0;
}

uint64
sys_get_process_info(void)
{
  // uint64 addr;
  // struct processinfo* st;
  // struct proc *p = myproc();

  // if(argaddr(1, &addr) < 0)
  //   return -1;
  
  // st->pid = p->pid;
  // st->name = p->name;
  // st->sz = p->sz;

  // if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
  //   return -1;
  
  return 0;
}