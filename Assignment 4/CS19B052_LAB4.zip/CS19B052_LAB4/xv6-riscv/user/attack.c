#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc, char* argv[]) {
	fork();
	wait(0);
	pcbread();
	exit(0);
}
